<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'unique_theme' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '1ga_%^>#Np-O|jpaHEyA<8+qT5EGULlGE(UOuIte25ChAtuc0y{8Kc<sJO+{{$xo' );
define( 'SECURE_AUTH_KEY',  'PdAep02/|IRs(}BB8QPpHc;)i JH[3S^kT;StL<T`AEeU(7T~?&AsR9)Lk~pJM_(' );
define( 'LOGGED_IN_KEY',    'VTO_i#_;>NL%e~(}f:*so<_z{iR!P3pj9NGka.6r+vDhEVTP,~+OA-,.5iy8%4c0' );
define( 'NONCE_KEY',        'AN}gx;(u:8Sqfo*2f+ /,CV&<C,H`f/d_62dXq,y8Ost*+;)5*m+apqSO^:C$@ae' );
define( 'AUTH_SALT',        'oPQKgZN`E zcktQd[``)a~#3}no%z}P{ (4GN]_<v@}ar*aMk%lH)(u u)powKPG' );
define( 'SECURE_AUTH_SALT', '$P0`M7`y`!OJq-DSA30dz`wLVa)WieX3^hRjG5Hs8?(!a!=-i!I)^8! 0`=>jTF_' );
define( 'LOGGED_IN_SALT',   'Mh~jY7&jV-FXggzwlzDCH!Y1vDmzK_@M-0&.f=+$iJ}8Nlje9g!/c28!!EB<eKDu' );
define( 'NONCE_SALT',       'G=5L$c!IAk9FbYWpY`2;vn0089B%RFA?4b%T)a6|v|HG M_j+^O0^OpP5Z67wlbP' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
